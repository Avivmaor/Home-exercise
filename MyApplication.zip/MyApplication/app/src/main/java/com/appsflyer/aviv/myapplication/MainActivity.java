package com.appsflyer.aviv.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import android.content.pm.ActivityInfo;
import android.os.Handler;
import android.util.Log;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import com.appsflyer.*;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        super.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        setContentView(R.layout.activity_main);
        graphicsHandler(2);
        AppsFlyerLib.getInstance().setImeiData("GET_DEVICE_IMEI");
         AppsFlyerLib.getInstance().setAndroidIdData("GET_DEVICE_ANDROID_ID");
         AppsFlyerLib.getInstance().setCustomerUserId("myId");
         AppsFlyerLib.getInstance().setCurrencyCode("USD");
        AppsFlyerLib.getInstance().startTracking(getApplication(), "NVYuNQW4hbAUvH2W89mM7S");
        AppsFlyerLib.getInstance().registerConversionListener(this, new AppsFlyerConversionListener() {

            public void onInstallConversionDataLoaded(Map<String, String> conversionData) {
                for (String attrName : conversionData.keySet()) {
                    Log.d(AppsFlyerLib.LOG_TAG, "attribute: " + attrName + " = " +
                            conversionData.get(attrName));
                }
                //SCREEN VALUES//
                final String install_type = "Install Type: " + conversionData.get("af_status");
                final String media_source = "Media Source: " + conversionData.get("media_source");
                final String install_time = "Install Time(GMT): " + conversionData.get("install_time");
                final String click_time = "Click Time(GMT): " + conversionData.get("click_time");
                runOnUiThread(new Runnable() {
                    public void run() {
                        ((TextView) findViewById(R.id.text_2)).setText(install_type + "\n" + media_source + "\n" + click_time + "\n" + install_time);
                    }
                });
            }
            public void onInstallConversionFailure(String errorMessage) {
                Log.d(AppsFlyerLib.LOG_TAG, "error getting conversion data: " + errorMessage);
                ((TextView) findViewById(R.id.text_2)).setText(errorMessage);
            }
            public void onAppOpenAttribution(Map<String, String> conversionData) {
            }
            public void onAttributionFailure(String errorMessage) {
                Log.d(AppsFlyerLib.LOG_TAG, "error onAttributionFailure : " + errorMessage);
            }
        });
    }

    public void buttonOnClick(View v) {
        Map<String, Object> eventValue = new HashMap<String, Object>();
        eventValue.put(AFInAppEventParameterName.REVENUE, 65);
        eventValue.put(AFInAppEventParameterName.CONTENT_TYPE, "Bingo!");
        eventValue.put(AFInAppEventParameterName.CONTENT_ID, "1234567");
        eventValue.put(AFInAppEventParameterName.CURRENCY, "USD");
        AppsFlyerLib.getInstance().trackEvent(getApplicationContext(), AFInAppEventType.PURCHASE, eventValue);
        graphicsHandler(2);
    }

    //Please ignore this function (handles sample app graphics)
    private void graphicsHandler(int c) {
        final Handler handler = new Handler();
        final TextView log = (TextView) findViewById(R.id.text_2);
        final Button button = (Button) findViewById(R.id.onlyBtn);
            button.setVisibility(View.VISIBLE);
            log.setVisibility(View.VISIBLE);
        }
    }







